
const app=document.getElementById('app');
const sidebar=document.getElementById('sidebar');
const pages={
home:()=>`<div class="page-head"><div><h1>WikiPro</h1><p class="subtitle">Enciclopédia das Backrooms</p></div></div>
<p>Bem-vindo à WikiPro. Consulte os registros disponíveis sobre as Backrooms.</p>
<div class="cards">
<a class="card" href="#niveis"><h3>▦ Níveis</h3><span class="status">Disponível</span><p class="muted">Consulte os níveis registrados.</p></a>
<a class="card" href="#nao-numerados"><h3>◇ Níveis Não Numerados</h3><span class="status closed">Em breve!</span></a>
<a class="card" href="#entidades"><h3>◉ Entidades</h3><span class="status closed">Em breve!</span></a>
<a class="card" href="#subniveis"><h3>⌘ Subníveis</h3><span class="status closed">Em breve!</span></a>
<a class="card" href="#informacoes"><h3>ⓘ Informações</h3><span class="status">Disponível</span><p class="muted">Créditos do projeto.</p></a></div>`,
niveis:()=>`<div class="page-head"><div><h1>Níveis</h1><p class="subtitle">Lista de níveis disponíveis</p></div><button class="back-x" data-back="home" aria-label="Voltar para a página inicial" title="Voltar para a página inicial">×</button></div>
<a class="card" href="#nivel-0"><h3>Nível 0 — Escuridão Suburbana</h3><span class="status">Disponível</span></a>`,
'nivel-0':()=>`<div class="page-head"><div><div class="crumb"><a href="#niveis">Níveis</a> / Nível 0</div><h1>Nível 0</h1><p class="subtitle">Escuridão Suburbana</p></div><button class="back-x" data-back="niveis" aria-label="Voltar para a lista de níveis" title="Voltar para a lista de níveis">×</button></div>
<img class="article-image" src="images/nivel-0/imagem-p1-1.jpeg" alt="Paisagem escura do Nível 0">
<p>Esse nível é o primeiro, o de entrada. As pessoas normalmente entram para as Backrooms dormindo, e acordam em uma casa aleatória de acordo com onde dormiram nesse nível. Entidades nunca foram vistas nesse nível. É possível achar outras pessoas nele.</p>
<p>O nível 0, também conhecido como Escuridão Suburbana, é semelhante a um subúrbio apagado. Ele não é finito e normalmente tem poucas fontes de luz.</p>
<h2>Fontes de luz</h2><h3>1: A Lua</h3><p>A lua é a principal fonte de luz. Algumas pessoas acham que é um buraco branco, mas isso não pode ser verdade.</p>
<img class="article-image" src="images/nivel-0/imagem-p2-1.jpeg" alt="Lua iluminando o céu do Nível 0">
<h3>2: Lanternas</h3><p>São encontradas em casas e têm baterias ilimitadas; são lanternas infinitas, por algum motivo.</p>
<h2>Entidades</h2><p>Não há entidades aqui.</p>
<h2>Entradas/saídas</h2><p>Em breve:)</p>
<div class="flow">Frontrooms → Nível 0 → Nível 1</div>
<p class="muted">Conteúdo transcrito do PDF enviado para a WikiPro.</p>`,
informacoes:()=>`<div class="page-head"><div><h1>Informações</h1><p class="subtitle">Créditos do projeto</p></div><button class="back-x" data-back="home" aria-label="Voltar para a página inicial" title="Voltar para a página inicial">×</button></div>
<div class="notice"><h3>Criado por</h3><p>Platinador</p></div><div class="notice"><h3>Programado por</h3><p>ChatGPT</p></div>`,
entidades:()=>coming('Entidades'),'subniveis':()=>coming('Subníveis'),'nao-numerados':()=>coming('Níveis Não Numerados')
};
function coming(name){return `<div class="page-head"><div><h1>${name}</h1></div><button class="back-x" data-back="home" aria-label="Voltar para a página inicial" title="Voltar para a página inicial">×</button></div><div class="notice"><h2>Em breve!</h2><p>Esta seção ainda está em desenvolvimento.</p></div>`}
function render(){let key=location.hash.replace('#','')||'home';if(!pages[key])key='home';app.innerHTML=pages[key]();document.querySelectorAll('.nav-link').forEach(a=>a.classList.toggle('active',a.dataset.page===key));app.querySelectorAll('[data-back]').forEach(b=>b.addEventListener('click',()=>location.hash=b.dataset.back));sidebar.classList.remove('open');}
window.addEventListener('hashchange',render);document.getElementById('menuToggle').addEventListener('click',()=>sidebar.classList.toggle('open'));render();
