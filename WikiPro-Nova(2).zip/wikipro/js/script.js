const app = document.getElementById('app');
const sidebar = document.getElementById('sidebar');
const menuToggle = document.getElementById('menuToggle');

const difficulty = value => `<div class="difficulty">Dificuldade: <strong>${value}</strong></div>`;
const backButton = target => `<button class="back-x" data-back="${target}" aria-label="Voltar" title="Voltar">×</button>`;
const pageHead = (title, subtitle, back) => `<div class="page-head"><div><h1>${title}</h1>${subtitle ? `<p class="subtitle">${subtitle}</p>` : ''}</div>${backButton(back)}</div>`;

const pages = {
  home: () => `
    <div class="page-head"><div><h1>WikiPro</h1><p class="subtitle">Enciclopédia das Backrooms</p></div></div>
    <p>Bem-vindo à WikiPro. Consulte os registros disponíveis sobre as Backrooms.</p>
    <div class="cards">
      <a class="card" href="#niveis"><h3>▦ Níveis</h3><span class="status">Disponível</span><p class="muted">Consulte os níveis registrados.</p></a>
      <a class="card" href="#nao-numerados"><h3>◇ Níveis Não Numerados</h3><span class="status closed">Em breve!</span></a>
      <a class="card" href="#entidades"><h3>◉ Entidades</h3><span class="status">Disponível</span><p class="muted">Consulte as entidades registradas.</p></a>
      <a class="card" href="#subniveis"><h3>⌘ Subníveis</h3><span class="status closed">Em breve!</span></a>
      <a class="card" href="#informacoes"><h3>ⓘ Informações</h3><span class="status">Disponível</span><p class="muted">Créditos do projeto.</p></a>
    </div>`,
  niveis: () => `
    ${pageHead('Níveis', 'Lista de níveis disponíveis', 'home')}
    <a class="card" href="#nivel-0"><h3>Nível 0 — Escuridão Suburbana</h3>${difficulty(0)}<span class="status">Disponível</span></a>
    <a class="card" href="#nivel-1"><h3>Nível 1 — Cruzeiro Vermelho</h3>${difficulty(1)}<span class="status">Disponível</span></a>`,
  'nivel-0': () => `
    ${pageHead('Nível 0', 'Escuridão Suburbana', 'niveis')}
    ${difficulty(0)}
    <img class="article-image" src="images/nivel-0/pagina-1.jpeg" alt="Paisagem escura do Nível 0">
    <p>Esse nível é o primeiro, o de entrada. As pessoas normalmente entram para as Backrooms dormindo, e acordam em uma casa aleatória de acordo com onde dormiram nesse nível. Entidades nunca foram vistas nesse nível. É possível achar outras pessoas nele.</p>
    <p>O nível 0, também conhecido como Escuridão Suburbana, é semelhante a um subúrbio apagado. Ele não é finito e normalmente tem poucas fontes de luz.</p>
    <h2>Fontes de luz</h2>
    <h3>1: A Lua</h3><p>A Lua é a principal fonte de luz. Algumas pessoas acham que é um Buraco Branco, mas isso não pode ser verdade.</p>
    <img class="article-image" src="images/nivel-0/pagina-2.jpeg" alt="Lua iluminando o céu do Nível 0">
    <h3>2: Lanternas</h3><p>Não tem muito o que falar disso. São encontradas em casas, têm baterias limitadas, só que são lanternas infinitas, por algum motivo.</p>
    <h2>Entidades</h2><div class="notice"><strong>Não há entidades aqui.</strong></div>
    <h2>Entradas/saídas</h2><p>Em breve :)</p>
    <div class="flow">Frontrooms → Nível 0 → Nível 1</div>`,
  'nivel-1': () => `
    ${pageHead('Nível 1', 'Cruzeiro Vermelho', 'niveis')}
    ${difficulty(1)}
    <img class="article-image" src="images/nivel-1/pagina-1.png" alt="Cruzeiro no mar vermelho sob uma lua vermelha">
    <p>Esse nível é semelhante a um cruzeiro em meio a um mar vermelho em uma noite infinita com lua vermelha.</p>
    <h2>Entidades</h2>
    <section class="entity"><h3>Andarilho</h3>
      <img class="article-image" src="images/nivel-1/pagina-2.png" alt="Andarilho em um corredor do cruzeiro">
      <p>Encontrado nos corredores do cruzeiro, simplesmente fecha caminhos. Você pode contorná-lo jogando qualquer coisa nele, até lanternas, e ele fugirá, desaparecendo por um dia.</p>
    </section>
    <section class="entity"><h3>Farol</h3>
      <img class="article-image" src="images/nivel-1/pagina-3.png" alt="Farol vermelho iluminando o mar escuro">
      <p>Iluminando o mar escuro em meio a uma noite eterna, é uma entidade inofensiva. Apesar de parecer ameaçadora, ela destruiu vários cruzeiros, mas parecem inabitados; por enquanto, o nível ainda é só um cruzeiro.</p>
    </section>
    <h2>Características do nível</h2>
    <p>Se você pular do cruzeiro, você entra no mar e começa a cair nele. Então, uma hora vai voltar à terra firme, no céu, caindo em cima do cruzeiro, curiosamente sem morrer.</p>
    <h2>Entradas e saídas</h2><h3>Entradas</h3><p>Atravesse uma porta no Nível 0.</p><h3>Saídas</h3><p>Em breve.</p>`,
  informacoes: () => `
    ${pageHead('Informações', 'Créditos do projeto', 'home')}
    <div class="notice"><h3>Criado por</h3><p>Platinador</p></div>
    <div class="notice"><h3>Programado por</h3><p>ChatGPT</p></div>
    <h2>Classificação de dificuldade</h2>
    <p>Os níveis podem receber uma classificação numérica de 0 a 5. Quanto maior o número, mais difícil é sobreviver no nível.</p>
    <p><strong>H</strong> = Habitável · <strong>?</strong> = Desconhecido · <strong>0–5</strong> = Dificuldade de sobrevivência.</p>`,
  entidades: () => `
    ${pageHead('Entidades', 'Entidades registradas nas Backrooms', 'home')}
    <p class="muted">Entidades conhecidas no Nível 1 — Cruzeiro Vermelho.</p>
    <a class="card" href="#entidade-andarilho"><h3>Andarilho</h3><span class="status">Nível 1</span><p>Fecha caminhos nos corredores do cruzeiro.</p></a>
    <a class="card" href="#entidade-farol"><h3>Farol</h3><span class="status">Nível 1</span><p>Ilumina o mar escuro em meio à noite eterna.</p></a>`,
  'entidade-andarilho': () => `
    ${pageHead('Andarilho', 'Entidade do Nível 1 — Cruzeiro Vermelho', 'entidades')}
    <img class="article-image" src="images/nivel-1/pagina-2.png" alt="Andarilho em um corredor do cruzeiro">
    <p>Encontrado nos corredores do cruzeiro, simplesmente fecha caminhos. Você pode contorná-lo jogando qualquer coisa nele, até lanternas, e ele fugirá, desaparecendo por um dia.</p>
    <p><strong>Nível:</strong> <a href="#nivel-1">Nível 1 — Cruzeiro Vermelho</a></p>`,
  'entidade-farol': () => `
    ${pageHead('Farol', 'Entidade do Nível 1 — Cruzeiro Vermelho', 'entidades')}
    <img class="article-image" src="images/nivel-1/pagina-3.png" alt="Farol vermelho iluminando o mar escuro">
    <p>Iluminando o mar escuro em meio a uma noite eterna, é uma entidade inofensiva. Apesar de parecer ameaçadora, ela destruiu vários cruzeiros, mas parecem inabitados; por enquanto, o nível ainda é só um cruzeiro.</p>
    <p><strong>Nível:</strong> <a href="#nivel-1">Nível 1 — Cruzeiro Vermelho</a></p>`,
  subniveis: () => coming('Subníveis'),
  'nao-numerados': () => coming('Níveis Não Numerados')
};

function coming(name) {
  return `${pageHead(name, '', 'home')}<div class="notice"><h2>Em breve!</h2><p>Esta seção ainda está em desenvolvimento.</p></div>`;
}

function render() {
  let key = location.hash.slice(1) || 'home';
  if (!pages[key]) key = 'home';
  app.innerHTML = pages[key]();
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.page === key);
  });
  app.querySelectorAll('[data-back]').forEach(button => {
    button.addEventListener('click', () => { location.hash = button.dataset.back; });
  });
  sidebar.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}
window.addEventListener('hashchange', render);
menuToggle.addEventListener('click', () => {
  const open = sidebar.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
render();
